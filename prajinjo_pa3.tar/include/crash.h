#ifndef CRASH_H_
#define CRASH_H_

void crash_response(int sock_index);
#endif
