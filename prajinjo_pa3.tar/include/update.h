#ifndef UPDATE_H_
#define UPDATE_H_

void process_update_payload(char* payload);
void update_response(int sock_index);

#endif
